package com.example.EmployeeManagementSystem.dto;

import org.springframework.beans.factory.annotation.Value;

public interface EmployeeProjection {

    // Using SpEL to fetch employee name and department name
    @Value("#{target.name + ' (' + target.department.name + ')'}")
    String getEmployeeInfo();

    String getName();

    String getEmail();

    // Fetch the department name directly from the Employee entity's associated Department
    @Value("#{target.department.name}")
    String getDepartmentName();
}
