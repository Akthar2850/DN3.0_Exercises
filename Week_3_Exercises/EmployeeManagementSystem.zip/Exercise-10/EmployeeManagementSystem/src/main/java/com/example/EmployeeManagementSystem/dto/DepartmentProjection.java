package com.example.EmployeeManagementSystem.dto;

import org.springframework.beans.factory.annotation.Value;

public interface DepartmentProjection {

    Long getId();

    String getName();

    // Fetch the number of employees in the department
    @Value("#{target.employees.size()}")
    int getEmployeeCount();
}
